create definer = root@localhost event upload_to_sdmp on schedule
    every '1' DAY
        starts '2020-06-30 00:00:00'
    enable
    do
    BEGIN
-- do something 编写你的计划任务要做的事
	INSERT INTO t_sign(NO,wtime,wstatues) SELECT NO,CURDATE(),0 FROM t_person;
-- 结束计划任务
END;

