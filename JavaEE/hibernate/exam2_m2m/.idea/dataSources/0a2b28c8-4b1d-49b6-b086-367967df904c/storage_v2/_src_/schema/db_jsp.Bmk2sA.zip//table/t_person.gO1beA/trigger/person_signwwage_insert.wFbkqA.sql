create definer = root@localhost trigger person_signwwage_insert
    after insert
    on t_person
    for each row
BEGIN
	INSERT INTO t_sign(NO,wtime,wstatues) 
	SELECT new.no,CURDATE(),0; #person和sign级联添加
	INSERT INTO t_wage(NO,Ssalary) 
	SELECT new.no,new.Psalary;#person和wage级联添加
END;

